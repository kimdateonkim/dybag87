document.addEventListener("DOMContentLoaded", () => {
    console.log("Luxury Bags website loaded!");
});